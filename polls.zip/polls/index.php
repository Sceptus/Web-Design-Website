<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Polls</title>
</head>
<body>
    <h1>Polls</h1>
    <a href="checkpoint-1">Checkpoint #1</a> <br /><br />
    <a href="checkpoint-2">Checkpoint #2</a>
</body>
</html>