<html lang="en">
<head>
</head>
<body>
    <form action="process_create.php" method="post">
        <label for="newFirstName">First Name: </label>
        <input id="newFirstName" type="text" name="newFirstName">
        <br />

        <label for="newLastName">Last Name: </label>
        <input id="newLastName" type="text" name="newLastName">
        <br />

        <label for="newEmail">E-Mail: </label>
        <input id="newEmail" type="text" name="newEmail">
        <br />

        <input type="submit" value="Insert">
    </form>
</body>
</html>