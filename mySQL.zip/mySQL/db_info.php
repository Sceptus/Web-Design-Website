<?php
    $server = "localhost";
    $db = "mthscsne_20232024";
    $username = "mthscsne_20232024";
    $password = "$#$20232024!!";
?>